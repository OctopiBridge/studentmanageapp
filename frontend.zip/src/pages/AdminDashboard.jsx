export default function AdminDashboard() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Admin Dashboard</h1>
      <p>Manage students and teachers</p>
    </div>
  );
}
