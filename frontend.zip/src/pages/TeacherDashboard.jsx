export default function TeacherDashboard() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Teacher Dashboard</h1>
      <p>Manage classes and students</p>
    </div>
  );
}
