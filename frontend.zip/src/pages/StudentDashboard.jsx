export default function StudentDashboard() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Student Dashboard</h1>
      <p>View courses, marks, and profile</p>
    </div>
  );
}
